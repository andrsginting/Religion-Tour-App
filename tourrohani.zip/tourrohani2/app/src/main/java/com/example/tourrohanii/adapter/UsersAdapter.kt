package com.example.tourrohanii

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tourrohanii.model.User


class UsersAdapter(
    private val onEditClick: (User) -> Unit,
    private val onDeleteClick: (User) -> Unit // Callback for delete action
) : RecyclerView.Adapter<UsersAdapter.UserViewHolder>() {

    private var userList = listOf<User>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.tvFullName.text = user.fullName
        holder.tvEmail.text = user.email
        holder.tvRole.text = user.role
        holder.tvDateOfBirth.text = user.dateOfBirth
        holder.tvAddress.text = user.address
        holder.tvGender.text = user.gender
        holder.tvPhoneNumber.text = user.phoneNumber

        holder.btnDelete.setOnClickListener {onDeleteClick(user)}
        holder.btnEdit.setOnClickListener { onEditClick(user) }
    }

    override fun getItemCount(): Int = userList.size

    fun submitList(users: List<User>) {
        userList = users
        notifyDataSetChanged()
    }

    class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFullName: TextView = view.findViewById(R.id.tvFullName)
        val tvEmail: TextView = view.findViewById(R.id.tvEmail)
        val tvRole: TextView = view.findViewById(R.id.tvRole)
        val tvDateOfBirth: TextView = view.findViewById(R.id.tvDateOfBirth)
        val tvAddress: TextView = view.findViewById(R.id.tvAddress)
        val tvGender: TextView = view.findViewById(R.id.tvGender)
        val tvPhoneNumber: TextView = view.findViewById(R.id.tvPhoneNumber)
        val btnEdit: Button = view.findViewById(R.id.btnEdit)
        val btnDelete: Button = view.findViewById(R.id.btnDelete) // Add Delete button
    }
}
