package com.example.tourrohanii.model

data class User(
    val id: String,
    val fullName: String,
    val email: String,
    val role: String,
    val dateOfBirth: String,
    val address: String,
    val gender: String,
    val phoneNumber: String
)