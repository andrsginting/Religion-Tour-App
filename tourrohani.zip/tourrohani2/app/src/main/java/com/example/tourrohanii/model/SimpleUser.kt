package com.example.tourrohanii.models

data class SimpleUser(
    val id: String,
    val fullName: String
)
