package com.example.tourrohanii

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileMenuFragment : Fragment() {
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile_menu, container, false)

        val txtFullName = view.findViewById<TextView>(R.id.txtFullName)
        val txtEmail = view.findViewById<TextView>(R.id.txtEmail)
        val txtPassword = view.findViewById<TextView>(R.id.txtPassword)
        val txtDateOfBirth = view.findViewById<TextView>(R.id.txtDateOfBirth)
        val txtAddress = view.findViewById<TextView>(R.id.txtAddress)
        val txtGender = view.findViewById<TextView>(R.id.txtGender)
        val txtPhoneNumber = view.findViewById<TextView>(R.id.txtPhoneNumber)
        val btnEditProfile = view.findViewById<Button>(R.id.btnEditProfile)

        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            Toast.makeText(context, "User not logged in!", Toast.LENGTH_SHORT).show()
            return view
        }

        btnEditProfile.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, EditProfileFragment())
                .addToBackStack(null)
                .commit()
        }

        // Load user data
        db.collection("users").document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    txtFullName.text = document.getString("fullName") ?: "-"
                    txtEmail.text = currentUser.email ?: "-"
                    txtPassword.text = "********"
                    txtDateOfBirth.text = document.getString("dateOfBirth") ?: "-"
                    txtAddress.text = document.getString("address") ?: "-"
                    txtGender.text = document.getString("gender") ?: "-"
                    txtPhoneNumber.text = document.getString("phoneNumber") ?: "-"
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Failed to load profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        // Open EditProfileFragment on button click
        btnEditProfile.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, EditProfileFragment())
                .addToBackStack(null)
                .commit()
        }

        return view
    }
}
