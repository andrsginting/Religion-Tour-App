package com.example.tourrohanii

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.firestore.FirebaseFirestore

class UsersDetailsFragment : Fragment() {
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_users_details, container, false)

        // Ambil userId yang dikirimkan dari fragment sebelumnya
        val userId = arguments?.getString("userId") ?: return view

        val tvFullName: TextView = view.findViewById(R.id.tvFullName)
        val tvDateOfBirth: TextView = view.findViewById(R.id.tvDateOfBirth)
        val tvAddress: TextView = view.findViewById(R.id.tvAddress)
        val tvGender: TextView = view.findViewById(R.id.tvGender)
        val tvPhoneNumber: TextView = view.findViewById(R.id.tvPhoneNumber)

        // Ambil data pengguna dari Firestore berdasarkan userId
        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    tvFullName.text = document.getString("fullName") ?: "-"
                    tvDateOfBirth.text = document.getString("dateOfBirth") ?: "-"
                    tvAddress.text = document.getString("address") ?: "-"
                    tvGender.text = document.getString("gender") ?: "-"
                    tvPhoneNumber.text = document.getString("phoneNumber") ?: "-"
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        return view
    }
}