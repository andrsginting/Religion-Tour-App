package com.example.tourrohanii

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tourrohanii.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AdminPanelActivity : AppCompatActivity() {

    private lateinit var recyclerViewUsers: RecyclerView
    private lateinit var usersAdapter: UsersAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_panel)

        val btnAddUser = findViewById<Button>(R.id.btnAddUser)
        recyclerViewUsers = findViewById(R.id.recyclerViewUsers)

        // Setup RecyclerView for Users
        recyclerViewUsers.layoutManager = LinearLayoutManager(this)
        usersAdapter = UsersAdapter(
            onEditClick = { user -> showEditUserDialog(user) },
            onDeleteClick = { user -> deleteUser(user) }
        )
        recyclerViewUsers.adapter = usersAdapter

        // Load Users from Firestore
        loadUsers()

        btnAddUser.setOnClickListener {
            showAddUserDialog()
        }
    }
    private fun showDeleteConfirmationDialog(user: User) {
        AlertDialog.Builder(this)
            .setTitle("Delete User")
            .setMessage("Are you sure you want to delete this user?")
            .setPositiveButton("Yes") { _, _ -> deleteUser(user) }
            .setNegativeButton("Cancel", null)
            .create()
            .show()
    }
    private fun showEditUserDialog(user: User) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_user, null)

        // Populate fields with current user data
        dialogView.findViewById<EditText>(R.id.edtEmail).setText(user.email)
        dialogView.findViewById<EditText>(R.id.edtFullName).setText(user.fullName)
        dialogView.findViewById<EditText>(R.id.edtRole).setText(user.role)
        dialogView.findViewById<EditText>(R.id.edtDateOfBirth).setText(user.dateOfBirth)
        dialogView.findViewById<EditText>(R.id.edtAddress).setText(user.address)
        dialogView.findViewById<EditText>(R.id.edtGender).setText(user.gender)
        dialogView.findViewById<EditText>(R.id.edtPhoneNumber).setText(user.phoneNumber)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Edit User")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val updatedUser = hashMapOf(
                    "email" to dialogView.findViewById<EditText>(R.id.edtEmail).text.toString(),
                    "fullName" to dialogView.findViewById<EditText>(R.id.edtFullName).text.toString(),
                    "role" to dialogView.findViewById<EditText>(R.id.edtRole).text.toString(),
                    "dateOfBirth" to dialogView.findViewById<EditText>(R.id.edtDateOfBirth).text.toString(),
                    "address" to dialogView.findViewById<EditText>(R.id.edtAddress).text.toString(),
                    "gender" to dialogView.findViewById<EditText>(R.id.edtGender).text.toString(),
                    "phoneNumber" to dialogView.findViewById<EditText>(R.id.edtPhoneNumber).text.toString()
                )
                updateUser(user.id, updatedUser)
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun updateUser(userId: String, updatedUser: Map<String, Any>) {
        db.collection("users").document(userId)
            .update(updatedUser)
            .addOnSuccessListener {
                Toast.makeText(this, "User updated successfully!", Toast.LENGTH_SHORT).show()
                loadUsers()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error updating user: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun deleteUser(user: User) {
        // Delete from Firebase Authentication
        db.collection("users").document(user.id)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "User data deleted from Firestore!", Toast.LENGTH_SHORT).show()

                // Delete user account from Firebase Authentication
                auth.currentUser?.delete()
                    ?.addOnSuccessListener {
                        Toast.makeText(this, "User account deleted successfully!", Toast.LENGTH_SHORT).show()
                        loadUsers() // Refresh the user list
                    }
                    ?.addOnFailureListener { e ->
                        Toast.makeText(this, "Error deleting user account: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error deleting user data: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    private fun showAddUserDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_user, null)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add New User")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val email = dialogView.findViewById<EditText>(R.id.edtEmail).text.toString()
                val password = dialogView.findViewById<EditText>(R.id.edtPassword).text.toString()
                val fullName = dialogView.findViewById<EditText>(R.id.edtFullName).text.toString()
                val role = dialogView.findViewById<EditText>(R.id.edtRole).text.toString()
                val dateOfBirth = dialogView.findViewById<EditText>(R.id.edtDateOfBirth).text.toString()
                val address = dialogView.findViewById<EditText>(R.id.edtAddress).text.toString()
                val gender = dialogView.findViewById<EditText>(R.id.edtGender).text.toString()
                val phoneNumber = dialogView.findViewById<EditText>(R.id.edtPhoneNumber).text.toString()

                val userData = hashMapOf(
                    "email" to email,
                    "fullName" to fullName,
                    "role" to role,
                    "dateOfBirth" to dateOfBirth,
                    "address" to address,
                    "gender" to gender,
                    "phoneNumber" to phoneNumber
                )

                createUser(email, password, userData)
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun createUser(email: String, password: String, userData: Map<String, Any>) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = task.result?.user?.uid
                    if (userId != null) {
                        db.collection("users").document(userId)
                            .set(userData)
                            .addOnSuccessListener {
                                Toast.makeText(this, "User created successfully!", Toast.LENGTH_SHORT).show()
                                loadUsers()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Error saving user: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    }
                } else {
                    Toast.makeText(this, "Error creating user: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun loadUsers() {
        db.collection("users").get()
            .addOnSuccessListener { snapshot ->
                val userList = snapshot.documents.map { document ->
                    User(
                        id = document.id,
                        fullName = document.getString("fullName") ?: "",
                        email = document.getString("email") ?: "",
                        role = document.getString("role") ?: "",
                        dateOfBirth = document.getString("dateOfBirth") ?: "",
                        address = document.getString("address") ?: "",
                        gender = document.getString("gender") ?: "",
                        phoneNumber = document.getString("phoneNumber") ?: ""
                    )
                }
                usersAdapter.submitList(userList)
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error loading users: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
