package com.example.tourrohanii

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tourrohanii.models.SimpleUser
import com.google.firebase.firestore.FirebaseFirestore

class UsersListFragment : Fragment() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var adapter: UsersListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_users_list, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerViewUsers)
        recyclerView.layoutManager = LinearLayoutManager(context)

        adapter = UsersListAdapter { user ->
            // Ketika nama user diklik, buka fragment baru untuk detail
            val bundle = Bundle()
            bundle.putString("userId", user.id)  // Kirim id pengguna yang dipilih
            val fragment = UsersDetailsFragment()   // Fragment untuk menampilkan detail
            fragment.arguments = bundle
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
        recyclerView.adapter = adapter

        // Load users dari Firestore
        db.collection("users")
            .whereEqualTo("role", "user")
            .get()
            .addOnSuccessListener { result ->
                val users = result.map { doc ->
                    SimpleUser(
                        id = doc.id,
                        fullName = doc.getString("fullName") ?: "-"
                    )
                }
                adapter.submitList(users)
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        return view
    }
}
