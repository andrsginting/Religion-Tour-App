package com.example.tourrohanii

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tourrohanii.models.SimpleUser


class UsersListAdapter(
    private val onItemClick: (SimpleUser) -> Unit
) : RecyclerView.Adapter<UsersListAdapter.UserViewHolder>() {

    private var userList = listOf<SimpleUser>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_simple_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.tvFullName.text = user.fullName


        // Set listener untuk menangani klik pada item (nama pengguna)
        holder.itemView.setOnClickListener { onItemClick(user) }
    }

    override fun getItemCount(): Int = userList.size

    fun submitList(users: List<SimpleUser>) {
        userList = users
        notifyDataSetChanged()
    }

    class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFullName: TextView = view.findViewById(R.id.tvFullName)
    }
}
