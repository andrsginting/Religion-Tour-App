package com.example.tourrohanii

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private lateinit var toolbar: Toolbar
    private lateinit var btnViewUsers: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        btnViewUsers = findViewById(R.id.btnViewUsers)
        btnViewUsers.setOnClickListener {
            btnViewUsers.visibility = View.GONE
            openFragment(UsersListFragment())
        }
        toolbar = findViewById(R.id.toolbar)

        val currentUser = auth.currentUser
        if (currentUser == null) {
            // Redirect to login if user is not logged in
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Load user name to toolbar
        db.collection("users").document(currentUser.uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val fullName = document.getString("fullName") ?: "User"
                    toolbar.title = "Hello, $fullName"
                } else {
                    toolbar.title = "Hello, User"
                }
            }
            .addOnFailureListener {
                toolbar.title = "Hello, User"
            }


        // Set click listener to open profileFragment
        toolbar.setOnClickListener {
            openFragment(ProfileMenuFragment())
        }
    }

    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}