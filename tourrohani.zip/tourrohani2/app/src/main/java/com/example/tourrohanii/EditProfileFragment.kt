package com.example.tourrohanii

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditProfileFragment : Fragment() {
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_edit_profile, container, false)

        val edtFullName = view.findViewById<EditText>(R.id.edtFullName)
        val edtDateOfBirth = view.findViewById<EditText>(R.id.edtDateOfBirth)
        val edtAddress = view.findViewById<EditText>(R.id.edtAddress)
        val edtGender = view.findViewById<EditText>(R.id.edtGender)
        val edtPhoneNumber = view.findViewById<EditText>(R.id.edtPhoneNumber)
        val btnSave = view.findViewById<Button>(R.id.btnSave)

        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            Toast.makeText(context, "User not logged in!", Toast.LENGTH_SHORT).show()
            return view
        }


        // Load current user data
        db.collection("users").document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    edtFullName.setText(document.getString("fullName"))
                    edtDateOfBirth.setText(document.getString("dateOfBirth"))
                    edtAddress.setText(document.getString("address"))
                    edtGender.setText(document.getString("gender"))
                    edtPhoneNumber.setText(document.getString("phoneNumber"))
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Failed to load profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        // Save updated data to Firestore
        btnSave.setOnClickListener {
            val userMap = mapOf(
                "fullName" to edtFullName.text.toString(),
                "dateOfBirth" to edtDateOfBirth.text.toString(),
                "address" to edtAddress.text.toString(),
                "gender" to edtGender.text.toString(),
                "phoneNumber" to edtPhoneNumber.text.toString()
            )

            db.collection("users").document(currentUser.uid)
                .update(userMap)
                .addOnSuccessListener {
                    Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                    parentFragmentManager.popBackStack() // Return to ProfileMenuFragment
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        return view
    }
}
